#ifndef MAIN_H_
#define MAIN_H_

#define F_CPU 8000000UL
#include <util/delay.h>
#include <stdbool.h>

#include "../Headers/io.h"
#include "../Headers/pwm.h"

//Konstansok
#define PWM_DUTY_MAX 255
#define PWM_DUTY_MIN 0
#define PWM_DELAY_MS 10

//F�ggv�nyek

#endif /* MAIN_H_ */