/*
 * 17. Fejezet
 *
 * A mikrovez�rl� PD7 l�b�ra kapcsolt LED f�nyerej�t folyamatosan v�ltoztatja,
 * a PWM kit�lt�si t�nyez�j�nek line�ris v�ltoztat�s�val.
 */

#include "../Headers/main.h"

int main(void)
{
    //Ki- �s bemenetek inicializ�l�sa
    IOInit();
    //PWM inicializ�l�sa
    PWMInit();

    //Felfel� kezdek sz�molni
    bool cntr_up = true;

    //V�gtelen ciklus
    while (1)
    {
        //PWM kit�lt�s n�vekedik
        if (cntr_up)
        {
            //Ha n�vekedhet m�g
            if (OCR2 < PWM_DUTY_MAX)
            {
                //N�velem
                OCR2++;
            }

            //Ha el�rte a maximumot
            else
            {
                //Ir�nyv�lt�s
                cntr_up = false;
            }
        }

        //PWM kit�lt�s cs�kken
        else
        {
            //Ha cs�kkenhet m�g
            if (OCR2 > PWM_DUTY_MIN)
            {
                //Cs�kkentem
                OCR2--;
            }

            //Ha el�rte a minimumot
            else
            {
                //Ir�nyv�lt�s
                cntr_up = true;
            }
        }

        //K�sleltet�s, hogy l�that� legyen a PWM v�ltoz�sa
        _delay_ms(PWM_DELAY_MS);
    }

    return 0;
}