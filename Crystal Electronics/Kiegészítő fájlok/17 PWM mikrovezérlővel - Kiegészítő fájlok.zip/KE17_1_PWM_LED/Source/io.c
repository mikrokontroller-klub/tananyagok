#include "../Headers/io.h"

void IOInit()
{
    //PORTA felh�z�ellen�ll�s kikapcsol�sa a bemeneteken
    PORTA = 0x00;
    DDRA = 0x00;

    //PORTB felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
    PORTB = 0x00;
    DDRB = 0x00;

    //PORTC felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
    PORTC = 0x00;
    DDRC = 0x00;

    //PORTD felh�z�ellen�ll�s kikapcsol�sa, minden bemenet kiv�ve a PWM pint
    PORTD = 0x00;
    DDRD = 0x00;
    //A PORTD PD7 pinje legyen kimenet, a timer2 PWM kimenete ezen a l�bon van
    sbi(DDRD, 7);
}