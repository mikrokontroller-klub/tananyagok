#include "../Headers/pwm.h"

void PWMInit()
{
    /*
     * A PWM frekvencia (adatlap 120.oldal) fpwm=fclkIO/(N*510), ahol N az �rajel oszt�sa.
     * Ebb�l N=fclkIO/fpwm*1/510, vagyis 10kHz k�r�li frekvenci�hoz N=8e6/10e3*1/510=1.569 oszt�s kell.
     * A mikrokontrollerben csak 1,8,32,64,128,256,1024 oszt�sok vannak, N=1-et v�lasztva
     * fpwm=15.686kHz ad�dik.
     *
     */

    //Egyszeres �rajel oszt�s a timer2 sz�m�ra
    cbi(TCCR2, CS22);
    cbi(TCCR2, CS21);
    sbi(TCCR2, CS20);
    //Pon�lt PWM m�k�d�s, OC2 kimenet 0, ha a sz�ml�l� nagyobb a k�sz�bn�l
    sbi(TCCR2, COM21);
    cbi(TCCR2, COM20);
    //Phase correct PWM m�d
    cbi(TCCR2, WGM21);
    sbi(TCCR2, WGM20);

    /* A sbi() �s cbi() f�ggv�nyek helyett, melyek a compat/deprecated.h f�jlban defini�ltak,
     * az egyes biteket a k�vetkez�, "vagy" logikai kapcsolaton alapul� megold�ssal is be�ll�thatjuk:
     * TCCR2 = TCCR2 | (0<<CS22) | (0<<CS21) | (1<<CS20);
     * Ez el�g �tl�thatatlan, �gy �rdemes a fenti f�ggv�nyeket alkalmazni.
     *
     * A C:\Program Files (x86)\Atmel\Atmel Toolchain\AVR8 GCC\Native\3.4.1061\avr8-gnu-toolchain\avr\include\compat\deprecated.h
     * f�jl tartalmazza a f�ggv�nyek defin�ci�j�t, l�that�, hogy a sbi() �s cbi() tulajdonk�ppen ezt a "vagy" kapcsolatos megold�st
     * val�s�tj�k meg (az el�r�si �t az oprendszert�l f�gg�en v�ltozhat).
     */
}
