#include "../Headers/music.h"

/*
 *   SUPER MARIO THEME
 */
//Dallam t�mb, le�r�s a mell�kelt xlsx f�jlban
volatile const uint16_t mario_notes[MARIO_LEN] = {30256, 30256, 0, 30256, 0, 38131, 30256, 0, 25444, 0, 0, 50890, 0, 0, 38131, 0, 0, 50890, 0, 60513, 0, 0, 45350, 0, 40403, 0, 42803, 45350, 0, 50890, 0, 30256, 0, 25444, 0, 22675, 0, 28570, 25444, 0, 30256, 0, 38131, 33984, 20201, 0, 38131, 0, 0, 50890, 0, 60513, 0, 0, 45350, 0, 40403, 0, 42803, 45350, 0, 50890, 0, 30256, 0, 25444, 22675, 0, 28570, 25444, 0, 30256, 0, 38131, 33984, 20201, 0, 0, 25444, 24023, 28570, 32076, 0, 30256, 0, 48047, 45350, 38131, 0, 45350, 38131, 33984, 0, 25444, 26971, 28570, 32076, 0, 30256, 0, 19110, 0, 19110, 19110, 0, 0, 0, 25444, 26971, 28570, 32076, 0, 30256, 0, 48047, 45350, 38131, 0, 45350, 38131, 33984, 0, 30256, 0, 0, 33984, 0, 38131, 0, 0, 0};
//Hang hossz�s�g t�mb (�tem), le�r�s a mell�kelt xlsx f�jlban
volatile const uint8_t mario_beats[MARIO_LEN] = {6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 6, 6, 4, 6, 6, 6, 6, 4, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 6, 6, 6, 6, 4, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 4, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 4, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 4, 6, 6, 6, 6, 4, 6, 6, 4, 2};

/*
 *   BOCI, BOCI, TARKA
 */
volatile const uint16_t boci_notes[BOCI_LEN] = {25420, 20170, 25420, 20170, 16963, 16963, 25420, 20170, 25420, 20170, 16963, 16963, 12710, 13467, 15116, 16963, 19047, 15116, 16963, 19047, 20170, 22655, 25420, 25420};
volatile const uint8_t boci_beats[BOCI_LEN] = {6, 6, 6, 6, 4, 4, 6, 6, 6, 6, 4, 4, 6, 6, 6, 6, 4, 4, 6, 6, 6, 6, 4, 4};


/*
 * Bet�lti a hangjegynek megfelel� sz�mot a timer compare regiszter�be
 */
void LoadNote(uint16_t note)
{
    //Ha sz�net van
    if (note == 0)
    {
        //Kimenet lev�laszt�sa a PWM modulr�l -> nincs kimen� jel
        DDRD = (0 << 5);
    }

    else
    {
        //Kimenet enged�lyez�se
        DDRD = (1 << 5);
        //Fels� 8 bit
        OCR1AH = (note >> 8);
        //Als� 8 bit
        OCR1AL = note & 0xFF;
    }
}

/*
 *Saj�t delay f�ggv�ny, a v�ltoz� k�sleltet�s miatt van r� sz�ks�g
 */
void MyDelay(uint16_t time)
{
    uint16_t i;

    for (i = 0; i < time ; i++)
    {
        _delay_ms(1);
    }
}

/*
 *Lej�tsza a param�terk�nt �tadott dallammot
 */
void Play(volatile const uint16_t* notes, volatile const uint8_t* beats, uint16_t length)
{
    uint8_t i = 0;
    uint8_t szunet;

    //Dallam t�mb iter�ci�ja
    for (i = 0; i < length; i++)
    {
        //Sz�net nagys�g�nak meghat�roz�sa
        szunet = SPEED / 100;
        //Aktu�lis hangjegy bet�lt�se
        LoadNote(notes[i]);

        //Hangjegy hossz�s�g�nak f�ggv�ny�ben v�rakoz�s
        switch (beats[i])
        {
        case 0:
            MyDelay(SPEED);
            break;

        case 1:
            MyDelay(SPEED * 3 / 4);
            break;

        case 2:
            MyDelay(SPEED * 1 / 2);
            break;

        case 3:
            MyDelay(SPEED * 3 / 8);
            break;

        case 4:
            MyDelay(SPEED * 1 / 4);
            break;

        case 5:
            MyDelay(SPEED * 3 / 16);
            break;

        case 6:
            MyDelay(SPEED * 1 / 8);
            break;

        case 7:
            MyDelay(SPEED * 3 / 32);
            break;

        case 8:
            MyDelay(SPEED * 1 / 16);
            break;

        case 9:
            MyDelay(SPEED * 3 / 64);

        case 10:
            MyDelay(SPEED * 1 / 32);
            break;
        }

        //Sz�net a hangjegyek k�z�tt, k�l�nben t�l legato (k�t�ttek) lenn�nek a hangok
        LoadNote(0);
        MyDelay(szunet);
    }
}