#include "../Headers/pwm.h"

/*
 * Inicializ�lja a PWM-hez sz�ks�ges timert
 */
void PWMInit()
{
    //OC1A �tbillent�se ha OCR1A megegyezik a sz�ml�l� �rt�k�vel 105.oldal
    cbi(TCCR1A, COM1A1);
    sbi(TCCR1A, COM1A0);
    //CTC (clear timer on compare match) �zemm�d 74.oldal
    cbi(TCCR1A, WGM10);
    cbi(TCCR1A, WGM11);
    sbi(TCCR1B, WGM12);
    cbi(TCCR1B, WGM13);
    //Egyszeres el�oszt�s 108. oldal, pwm_notes.xlsx alapj�n
    sbi(TCCR1B, CS10);
    cbi(TCCR1B, CS11);
    cbi(TCCR1B, CS12);
}

