/*
 * 17. Fejezet
 *
 * A mikrovez�rl� PD5 l�b�n a szoftverben megadott dallamnak megfelel�
 * frekvenci�j� n�gysz�gjel jelenik meg, melyek hankelt� eszk�zzel meg
 * lehet sz�laltatni.
 */

#include "../Headers/main.h"


int main(void)
{
    //Ki- �s bemenetek inicializ�l�sa
    IOInit();
    //PWM inicializ�l�sa
    PWMInit();

    //V�gtelen ciklus
    while (1)
    {
        //Dallamok lej�tsz�sa
        Play(boci_notes, boci_beats, BOCI_LEN);
        Play(mario_notes, mario_beats, MARIO_LEN);
    }

    return 0;
}