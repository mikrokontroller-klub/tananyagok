#ifndef MUSIC_H_
#define MUSIC_H_

#include "../Headers/pwm.h"

//Sebess�g, az eg�sz hanghoz tartoz� id�tartam tizede ms-ban
//pl. speed=100-> 1000ms, 20->200ms
#define SPEED 1500

/*
 *   SUPER MARIO THEME
 */
//Mario dallam hangjegyeinek sz�ma
#define MARIO_LEN 131
//Dallam t�mb, le�r�s a mell�kelt xlsx f�jlban
extern volatile const uint16_t mario_notes[MARIO_LEN];
//Hang hossz�s�g t�mb (�tem), le�r�s a mell�kelt xlsx f�jlban
extern volatile const uint8_t mario_beats[MARIO_LEN];

/*
 *   BOCI, BOCI, TARKA
 */
#define BOCI_LEN 24
extern volatile const uint16_t boci_notes[BOCI_LEN];
extern volatile const uint8_t boci_beats[BOCI_LEN];

//F�ggv�nyek
void Play(volatile const uint16_t* notes, volatile const uint8_t* beats, uint16_t length);

#endif /* MUSIC_H_ */