#ifndef PWM_H_
#define PWM_H_

#include <avr/io.h>
#define F_CPU 8000000UL
#include <util/delay.h>
#include <compat/deprecated.h>

//F�ggv�nyek
void PWMInit();

#endif /* PWM_H_ */
