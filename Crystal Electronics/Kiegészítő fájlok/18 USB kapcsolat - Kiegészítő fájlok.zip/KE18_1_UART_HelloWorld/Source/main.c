#include <avr/io.h>

void UARTInit( unsigned int ubrr)
{
    /* Baud rate be�ll�t�sa */
    UBRRH = (unsigned char)(ubrr>>8);
    UBRRL = (unsigned char)ubrr;
    /* Ad� �s ve� enged�lyez�se */
    UCSRB = (1<<RXEN)|(1<<TXEN);
    /* Frame form�tum be�ll�t�sa: 8data, 2stop bit */
    UCSRC = (1<<URSEL)|(1<<USBS)|(3<<UCSZ0);
}

void UARTTransmit( unsigned char data )
{
    /* Addig v�runk, am�g az ad� buffer ki nem �r�l */
    while ( !( UCSRA & (1<<UDRE)) )
	{
		/* �res ciklus. Nem csin�lunk m�st csak v�runk. */
	}
    /* Betessz�k az adatot a bufferbe.
	 * A k�ld�st a mikrokontroller HW megoldja. */
    UDR = data;
}

void UARTTransmitString(char string[])
{
    unsigned char iterator;
    for(iterator = 0; string[iterator] != '\0'; iterator++)
    {
        UARTTransmit(string[iterator]);
    }
}

int main(void)
{
    char helloWorld[] = "Hello World!";
	
    /* PORTA felh�z�ellen�ll�sok bekapcsol�sa a bemeneteken
     * PA0 kimenet legyen logikai 1 jelszinttel(5V), ezen a l�bon van st�tusz LED
	 * A t�bbi pin legyen bemenet */
    PORTA = 0xFF;
    DDRA = 0x01;

    /* PORTB felh�z�ellen�ll�sok bekapcsol�sa �s minden pin bemenet */
    PORTB = 0xFF;
    DDRB = 0x00;

    /* PORTC felh�z�ellen�ll�sok bekapcsol�sa �s minden pin bemenet */
    PORTC = 0xFF;
    DDRC = 0x00;

    /* PORTD felh�z�ellen�ll�sok bekapcsol�sa �s minden pin bemenet */
    PORTD = 0xFF;
    DDRD = 0x00;
    
    UARTInit(103);
    
    UARTTransmitString(helloWorld);
        
    while(1)
    {
		/* V�gtelen ciklus */
    }
	
	/* Ide sosem jutunk el, de szintaktikailag illik ide tenni */
	return 0;
}

