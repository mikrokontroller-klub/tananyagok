#ifndef UART_H_
#define UART_H_

#include <avr/io.h>
#include <stdio.h>

//Függvények
void UARTInit(unsigned int);

void UARTPutchar(char c, FILE *stream);
char UARTGetchar(FILE *stream);

#endif /* UART_H_ */