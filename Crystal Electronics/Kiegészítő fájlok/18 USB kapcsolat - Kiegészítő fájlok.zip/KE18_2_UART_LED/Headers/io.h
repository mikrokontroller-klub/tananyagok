#ifndef IO_H_
#define IO_H_

#include <avr/io.h>

//Konstansok

//Függvények
void IOInit();

#endif /* IO_H_ */