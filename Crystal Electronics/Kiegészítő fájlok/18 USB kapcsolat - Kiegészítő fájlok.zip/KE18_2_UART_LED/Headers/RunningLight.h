#ifndef RUNNINGLIGHT_H_
#define RUNNINGLIGHT_H_

#include <avr/io.h>

void RunningLightLeft(void);
void RunningLightRight(void);



#endif /* RUNNINGLIGHT_H_ */