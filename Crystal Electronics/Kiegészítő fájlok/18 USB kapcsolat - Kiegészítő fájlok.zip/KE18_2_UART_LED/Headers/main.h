#ifndef MAIN_H_
#define MAIN_H_

#include "../Headers/io.h"
#include "../Headers/UART.h"
#include "../Headers/RunningLight.h"

#define F_CPU 8000000UL
#include <util/delay.h>
#include <string.h>
#include <compat/deprecated.h>
#include <stdio.h>

//Konstansok
#define LED_CODE 0x55
#define LEFT	 0x3C
#define RIGHT	 0x3E

//Függvények
void SendStringOnUART();

#endif /* MAIN_H_ */