/*
 * 18. Fejezet: Fut�f�ny
 */
#include "../Headers/main.h"


int main(void)
{
    /* Buffer v�ltoz� a vett adat sz�m�ra */
	char buffer;

    /* Ki- �s bemenetek inicializ�l�sa */
    IOInit();
	
	/* Valid kezd��rt�k be�ll�t�sa PORTB-nek */
	PORTB = 0x01;
	
    /* UART inicializ�l�sa, 103=4800 baud, 165.oldal ATmega16A atatlap */
    UARTInit(103);
	
	FILE uart_output = FDEV_SETUP_STREAM(UARTPutchar,	NULL,			_FDEV_SETUP_WRITE);
	FILE uart_input  = FDEV_SETUP_STREAM(NULL,			UARTGetchar,	_FDEV_SETUP_READ);
	stdout = &uart_output;
	stdin  = &uart_input;
	
    /* Tesztel�s */
    puts("****UART initialized.****");
	
    /* V�gtelen ciklus */
    while (1)
    {
        /* A vett adatot bet�lt�m a bufferbe */
        buffer = getchar();

		/* Be�rkez� adat feldolgoz�sa switch-case szerkezettel:
		 * A szerkezet lehet�v� teszi, hogy a vizsg�land� v�ltoz�t egy list�nyi
		 * adattal vess�k �ssze. Minden egyes adat �rt�k egy case-nek felel meg.
		 */
		switch(buffer)
		{
			case LED_CODE:
			{
				puts("Led billentes erkezett");
				PORTA = ~PORTA;
				break;
			}
			case LEFT:
			{
				puts("Futofeny balra parancs erkezett");
				RunningLightLeft();
				break;
			}
			case RIGHT:
			{
				puts("Futofeny jobbra parancs erkezett");
				RunningLightRight();
				break;
			}
			default:
			{
				printf("Ismeretlen parancs: %c \n", buffer );
				break;
			}
		}
    }

    return 0;
}