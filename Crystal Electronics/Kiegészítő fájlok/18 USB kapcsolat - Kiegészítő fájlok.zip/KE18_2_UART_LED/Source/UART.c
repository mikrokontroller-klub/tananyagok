#include "../Headers/UART.h"

void UARTInit( unsigned int ubrr)
{
    /* Baud rate beállítása */
    UBRRH = (unsigned char)(ubrr>>8);
    UBRRL = (unsigned char)ubrr;
    /* Adó és veő engedélyezése */
    UCSRB = (1<<RXEN)|(1<<TXEN);
    /* Frame formátum beállítása: 8data, 2stop bit */
    UCSRC = (1<<URSEL)|(1<<USBS)|(3<<UCSZ0);
}


void UARTPutchar(char c, FILE *stream) {
    /* Ha sor vége karakter jön, akkor be kell szúrni egy \r-t
     * hogy windows kompatibilis legyen */
    if( c == '\n')
    {
        loop_until_bit_is_set(UCSRA, UDRE);
        UDR = '\r';
    }
    
    loop_until_bit_is_set(UCSRA, UDRE);
    UDR = c;
}

char UARTGetchar(FILE *stream) {
    loop_until_bit_is_set(UCSRA, RXC); /* Addig várunk, amíg nem érkezik adat. */
    return UDR;
}