#include "../Headers/io.h"

void IOInit()
{
    /* PORTA felhúzóellenállások bekapcsolása a bemeneteken
     * PA0 kimenet legyen logikai 1 jelszinttel(5V), ezen a lábon van státusz LED
	 * A többi pin legyen bemenet */
    PORTA = 0xFF;
    DDRA = 0x01;

    /* PORTB felhúzóellenállások kikapcsolása és minden pin kimenet */
    PORTB = 0x00;
    DDRB = 0xFF;

    /* PORTC felhúzóellenállások bekapcsolása és minden pin bemenet */
    PORTC = 0xFF;
    DDRC = 0x00;

    /* PORTD felhúzóellenállások bekapcsolása és minden pin bemenet */
    PORTD = 0xFF;
    DDRD = 0x00;
}
