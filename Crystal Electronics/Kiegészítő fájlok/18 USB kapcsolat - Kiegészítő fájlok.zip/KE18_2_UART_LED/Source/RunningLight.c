#include "../Headers/RunningLight.h"

void RunningLightLeft(void)
{
	PORTB = (PORTB != 0x80) ? (PORTB << 1) : (0x01);
}


void RunningLightRight(void)
{
	PORTB = (PORTB != 0x01) ? (PORTB >> 1) : (0x80);
}