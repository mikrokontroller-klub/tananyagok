#ifndef MAIN_H
#define MAIN_H

//////////////////////////////////// Konstansok

// 8 MHz-es �rajellel dolgozunk
#define F_CPU 8000000UL

// Ennyi m�sodperc egy napban
#define SECONDS_PER_DAY (24UL * 60 * 60)

//////////////////////////////////// F�ggv�nyek

// Nincs olyan f�ggv�ny a main.c-ben, amit m�s file-b�l h�vn�nk

#endif /* MAIN_H_ */
