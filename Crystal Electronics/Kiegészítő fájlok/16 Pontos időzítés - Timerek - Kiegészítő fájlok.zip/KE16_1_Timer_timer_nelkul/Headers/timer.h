#ifndef TIMER_H_
#define TIMER_H_


//////////////////////////////////// F�ggv�nyek

// F�ggv�ny arra, hogy v�rakozzunk egy m�sodpercet
void WaitSecond(void);


#endif /* TIMER_H_ */