#include "../Headers/io.h"

#include <avr/io.h>

// F�ggv�ny az I/O pinek inicializ�l�s�ra
void IoInit(void)
{
    // Hat LED a PA[0..5]-�n -> ezek legyenek kimenetek
    DDRA =  (1 << PA0) | (1 << PA1) | (1 << PA2) | (1 << PA3) | (1 << PA4) | (1 << PA5);
    PORTA = 0;

    // �t LED a PB[0..4]-en -> ezek legyenek kimenetek
    DDRB =  (1 << PB0) | (1 << PB1) | (1 << PB2) | (1 << PB3) | (1 << PB4);
    PORTB = 0;

    // 1 LED a PORTC[0]-n
    DDRC =  (1 << PC0);
    PORTC = 0;

    // PORTD minden pinje bemenet, felh�z�ellen�ll�s PD[2:3]-on
    DDRD =  0;
    PORTD = (1 << PD2) | (1 << PD3);
}

// F�ggv�ny a LED-ek friss�t�s�re az id�nek megfelel�en
// I/O kimenet: LED kimenetek fel�l�r�sa
// time: a kijelzend� id� m�sodpercben �jf�l �ta
void UpdateDisplay(uint32_t time)
{
    // A PORTA-n l�v� LED-ek a perceket jelzik ki
    PORTA = (time % 3600) / 60;

    // A PORTB-n l�v� LED-ek az �r�kat jelzik ki
    PORTB = time / 3600;

    // PORTC[0] m�sodpercenk�nt villog
    PORTC = time % 2;
}

// F�ggv�ny az id� m�dos�t�s�ra a gombok �ll�sa alapj�n
// I/O bemenet: nyom�gombok
// time: a kijelzend� id� m�sodpercben �jf�l �ta
// visszat�r�si �rt�k: az �j id�
uint32_t SetTime(uint32_t time)
{
    uint32_t newtime = time;

    if ((PIND & 0b0100) == 0)
    {
        // a percgomb le van nyomva
        newtime = time + 60;
    }
    else if ((PIND & 0b1000) == 0)
    {
        // az �ragomb le van nyomva
        newtime = time + 3600;
    }
    else
    {
        // egyik gomb sincs lenyomva
        newtime = time;
    }

    return newtime;
}
