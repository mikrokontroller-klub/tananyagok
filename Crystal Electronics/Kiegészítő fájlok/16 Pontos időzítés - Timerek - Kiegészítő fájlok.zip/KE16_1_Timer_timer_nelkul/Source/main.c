/*
 * 16. fejezet
 *
 * _16_1_Timer_without_timer.c
 *
 */

#include "../Headers/main.h"
#include "../Headers/io.h"
#include "../Headers/timer.h"

#include <util/delay.h>
#include <avr/io.h>

int main(void)
{
    uint32_t time = 0;

    IoInit();

    while (1)
    {
        time = SetTime(time);

        UpdateDisplay(time);

        WaitSecond();

        time++;
        if (time >= SECONDS_PER_DAY)
        {
            time = 0;
        }
    }

    return 0;
}
