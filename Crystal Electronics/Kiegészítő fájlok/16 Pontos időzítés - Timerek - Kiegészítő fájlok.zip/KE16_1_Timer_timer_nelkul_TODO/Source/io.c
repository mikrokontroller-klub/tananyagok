#include "../Headers/io.h"

#include <avr/io.h>

// F�ggv�ny az I/O pinek inicializ�l�s�ra
void IoInit(void)
{
    // Hat LED a PA[0..5]-�n -> ezek legyenek kimenetek
    // TODO  DDRA = ...;
    // TODO  PORTA = ...;

    // �t LED a PB[0..4]-en -> ezek legyenek kimenetek
    // TODO

    // 1 LED a PORTC[0]-n
    // TODO

    // PORTD minden pinje bemenet, felh�z�ellen�ll�s PD[2:3]-on
    // TODO
}

// F�ggv�ny a LED-ek friss�t�s�re az id�nek megfelel�en
// I/O kimenet: LED kimenetek fel�l�r�sa
// time: a kijelzend� id� m�sodpercben �jf�l �ta
void UpdateDisplay(uint32_t time)
{
    // A PORTA-n l�v� LED-ek a perceket jelzik ki
    // TODO

    // A PORTB-n l�v� LED-ek az �r�kat jelzik ki
    // TODO

    // PORTC[0] m�sodpercenk�nt villog
    // TODO
}

// F�ggv�ny az id� m�dos�t�s�ra a gombok �ll�sa alapj�n
// time: a kijelzend� id� m�sodpercben �jf�l �ta
// I/O bemenet: nyom�gombok
// visszat�r�si �rt�k: az �j id�
uint32_t SetTime(uint32_t time)
{
    uint32_t newtime = time;

    if (/* TODO */ 0)
    {
        // a percgomb le van nyomva
        // newtime = TODO;
    }
    else if (/* TODO */ 0)
    {
        // az �ragomb le van nyomva
        // TODO
    }
    else
    {
        // egyik gomb sincs lenyomva
        // TODO
    }

    return newtime;
}
