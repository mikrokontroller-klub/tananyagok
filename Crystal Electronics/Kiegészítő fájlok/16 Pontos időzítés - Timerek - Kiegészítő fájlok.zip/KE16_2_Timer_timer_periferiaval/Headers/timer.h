#ifndef TIMER_H_
#define TIMER_H_

#include <stdbool.h>

//////////////////////////////////// F�ggv�nyek

// F�ggv�ny a timer perif�ria inicializ�l�s�ra
void SetupTimer(void);

// E f�ggv�ny visszat�r�si �rt�ke megmutatja, a timer perif�ri�ban eltelt-e egy m�sodperc
// false: nem telt el
// true: eltelt egy m�sodperc
bool CheckIfSecondElapsed(void);

#endif /* TIMER_H_ */