#include "../Headers/timer.h"

#include <avr/io.h>

//////////////////////////////////// F�ggv�nyek

// F�ggv�ny a timer perif�ria inicializ�l�s�ra
void SetupTimer(void)
{
    // 1. Timer input be�ll�t�sa TOSC1-2 pinekre
    ASSR |= (1 << AS2);

    // 2. Timer m�d be�ll�t�sa: Clear Timer on Compare Match (WGM2[1:0] = 0b10)
    TCCR2 |= (1 << WGM21);
    // WGM20 �rt�ke 0, nem kell �ll�tani

    // 3. Timer maxim�lis �rt�k�nek be�ll�t�sa
    // Le�r�s�rt l�sd a 17-11. �br�t (Timer/Counter2 Timing Diagram, CTC mode, with prescaler)
    // �s a k�pletet a a 17.7.2. fejezetben (Timer2 CTC mode).
    OCR2 = 31;

    // 4. Prescaler be�ll�t�sa: clk_TS2 / 1024 (CS2[2:0] = 0b111)
    // (Ez egy�ttal elind�tja a Timer2-ben a sz�mol�st, ami eddig �llt.)
    TCCR2 |= (1 << CS22) | (1 << CS21) | (1 << CS20);
}

// E f�ggv�ny visszat�r�si �rt�ke megmutatja, a timer perif�ri�ban eltelt-e egy m�sodperc
// false: nem telt el
// true: eltelt egy m�sodperc
bool CheckIfSecondElapsed(void)
{
    bool second_elapsed_b;

    if (0 != (TIFR & (1 << OCF2)))
    {
        // Resetelj�k az OCF2 bitet
        TIFR = (1 << OCF2);

        second_elapsed_b = true;
    }
    else
    {
        second_elapsed_b = false;
    }

    return (second_elapsed_b);
}
