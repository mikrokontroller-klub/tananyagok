/*
 * 16. fejezet
 *
 * _16_2_Timer_with_timer.c
 *
 */

#include "../Headers/main.h"
#include "../Headers/io.h"
#include "../Headers/timer.h"

#include <util/delay.h>
#include <avr/io.h>

int main(void)
{
    uint32_t time_seconds = 0;

    IoInit();
    SetupTimer();

    while (1)
    {
        time_seconds = SetTime(time_seconds);

        UpdateDisplay(time_seconds);

        while (CheckIfSecondElapsed() == false)
        {
            // sz�nd�kosan �res ciklusmag
        }

        time_seconds++;
        if (time_seconds >= SECONDS_PER_DAY)
        {
            time_seconds = 0;
        }
    }

    return 0;
}
