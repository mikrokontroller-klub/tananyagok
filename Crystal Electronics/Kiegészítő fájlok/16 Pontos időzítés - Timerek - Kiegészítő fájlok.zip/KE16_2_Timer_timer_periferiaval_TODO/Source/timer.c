#include "../Headers/timer.h"

#include <avr/io.h>

//////////////////////////////////// F�ggv�nyek

// F�ggv�ny a timer perif�ria inicializ�l�s�ra
void SetupTimer(void)
{
    // TODO 1. Timer input be�ll�t�sa TOSC[1:2] pinekre

    // TODO 2. Timer m�d be�ll�t�sa: Clear Timer on Compare Match (WGM2[1:0] = 0b10)

    // TODO 3. Timer maxim�lis �rt�k�nek be�ll�t�sa (OCR2 regiszter)
    // Le�r�s�rt l�sd a 17-11. �br�t (Timer/Counter2 Timing Diagram, CTC mode, with prescaler)
    // �s a k�pletet a a 17.7.2. fejezetben (Timer2 CTC mode).

    // TODO 4. Prescaler be�ll�t�sa: clk_TS2 / 1024 (CS2[2:0] = 0b111)
    // (Ez egy�ttal elind�tja a Timer2-ben a sz�mol�st, ami eddig �llt.)
}

// E f�ggv�ny visszat�r�si �rt�ke megmutatja, a timer perif�ri�ban eltelt-e egy m�sodperc
// false: nem telt el
// true: eltelt egy m�sodperc
bool CheckIfSecondElapsed(void)
{
    bool second_elapsed_b;

    if (0 != (TIFR & (1 << OCF2)))
    {
        // Resetelj�k az OCF2 bitet
        TIFR = (1 << OCF2);

        second_elapsed_b = true;
    }
    else
    {
        second_elapsed_b = false;
    }

    return second_elapsed_b;
}
