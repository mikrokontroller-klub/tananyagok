#include "../Headers/adc.h"

volatile enum ADC_state_t ADC_state;

void ADCInit()
{
    //AVCC referencia
    cbi(ADMUX, REFS1);
    sbi(ADMUX, REFS0);

    //ADC1 bemenet
    sbi(ADMUX, MUX0);
    ADC_state = poti1;

    //Balra tolt eredm�ny -> fels� 8 bit ADCRH-ban
    sbi(ADMUX, ADLAR);
}

void ADCEnable()
{
    //128-as presc
    sbi(ADCSRA, ADPS2);
    sbi(ADCSRA, ADPS1);
    sbi(ADCSRA, ADPS0);

    //Interrupt bekapcsol�sa
    sbi(ADCSRA, ADIE);

    //AD konverter bekapcsol�sa
    sbi(ADCSRA, ADEN);
}


void ADCStart()
{
    sbi(ADCSRA, ADSC);
}

//K�vetkez� AD csatorn�ra v�lt�s
void NextCH()
{
    switch (ADC_state)
    {
    //ADC1 l�bon a potenciom�ter1 van
    case poti1:
        //A k�vetkez� l�b az ADC2
        cbi(ADMUX, MUX0);
        sbi(ADMUX, MUX1);
        ADC_state = poti2;
        break;

    //ADC2 l�bon a potenciom�ter2 van
    case poti2:
        //A k�vetkez� l�b az ADC1
        cbi(ADMUX, MUX1);
        sbi(ADMUX, MUX0);
        ADC_state = poti1;
        break;

    default:
        break;
    }
}