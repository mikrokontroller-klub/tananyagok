/*
 * 23. Fejezet
 *
 * A PA1 (ADC1) l�bon lev� potenciom�ter fesz�lts�g�t �sszehasonl�tja
 * egy m�sik (PA2, ADC2) l�bon lev� potencim�ter fesz�lts�g�vel (AD konverzi�).
 * Ha a k�t m�rt fesz�lts�g k�l�nbs�ge nagyobb mint 1V, akkor
 * a PA0 l�bon lev� LED kigyullad. Ellenkez� esetben nem vil�g�t.
 */

#include "../Headers/main.h"

volatile uint32_t cntr = 0;
volatile double U_poti1 = 0;
volatile double U_poti2 = 0;

//Timer1 megszak�t�s
ISR(TIMER1_OVF_vect)
{
    //N�velem a leoszt� sz�ml�l�t, ha m�g nem �rte el a maximumot
    if (cntr < CNTR_MAX)
    {
        cntr++;
    }

    //Ha el�rte
    else
    {
        cntr = 0;
        //AD konverzi� indul (mintav�tel)
        ADCStart();
    }
}

ISR(ADC_vect)	//AD konverzi� k�sz
{
    //Az AD csatorna alapj�n a megfelel� v�ltoz�ba menti a m�rt fesz�lts�get
    switch (ADC_state)
    {
    case poti1:
        U_poti1 = ADCH * ADC_CONST;
        break;

    case poti2:
        U_poti2 = ADCH * ADC_CONST;
        break;

    default:
        break;
    }

    //V�lt�s a k�vetkez� AD csatorn�ra
    NextCH();
}

int main(void)
{
    IOInit();
    TimerInit();
    ADCInit();

    //AD enged�lyez�se
    ADCEnable();

    //V�gtelen ciklus
    while (1)
    {
        //Ha 1V-n�l nagyobb az elt�r�s
        if (fabs(U_poti1 - U_poti2) > 1)
        {
            //Led vil�g�t
            sbi(PORTA, 0);
        }

        //Ha 1V-n�l kisebb az elt�r�s
        else
        {
            //Nem vil�g�t a LED
            cbi(PORTA, 0);
        }
    }

    return 0;
}