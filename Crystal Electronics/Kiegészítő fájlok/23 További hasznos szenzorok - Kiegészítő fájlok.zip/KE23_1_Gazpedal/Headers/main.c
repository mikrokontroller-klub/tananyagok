#include "../Headers/main.h"

ISR(TIMER1_OVF_vect)	//Timer1 lej�rt
{
    if (cntr < CNTR_MAX)
    {
        cntr++;
    }

    else
    {
        cntr = 0;
        PORTA = PORTA ^ 0x01;
        ADCStart();		//AD konverzi� indul (mintav�tel)
    }
}

ISR(ADC_vect)	//AD konverzi� k�sz
{
    switch (ADC_state)
    {
    case poti:
        U_poti = ADCH * ADC_CONST;
        break;

    case NTC:
        U_NTC = ADCH * ADC_CONST;
        break;

    default:
        break;
    }

    NextCH();	//V�lt�s a k�vetkez� AD csatorn�ra
}

int main(void)
{
    IOInit();
    TimerInit();
    ADCInit();
    ADCEnable();
    OCR2 = 0;	//PWM kit�lt�se legyen kezdetben 0

    while (1)
    {
        if (U_NTC > U_poti)
        {
            sbi(PORTA, 0);
        }

        else
        {
            cbi(PORTA, 0);
        }
    }
}