#include "../Headers/adc.h"


void ADCInit()
{
    //AVCC referencia
    cbi(ADMUX, REFS1);
    sbi(ADMUX, REFS0);

    //ADC1 bemenet
    sbi(ADMUX, MUX0);
	ADC_state = poti;

    //Balra tolt eredm�ny -> fels� 8 bit ADCRH-ban
    sbi(ADMUX, ADLAR);
}

void ADCEnable()
{
    //128-as presc
    sbi(ADCSRA, ADPS2);
    sbi(ADCSRA, ADPS1);
    sbi(ADCSRA, ADPS0);

    //Interrupt bekapcsol�sa
    sbi(ADCSRA, ADIE);

    //AD konverter bekapcsol�sa
    sbi(ADCSRA, ADEN);
}


void ADCStart()
{
    sbi(ADCSRA, ADSC);
}

void NextCH()	//K�vetkez� AD csatorna
{
    switch (ADC_state)
    {
    case poti:	//ADC1 l�bon a potenciom�ter van
		cbi(ADMUX, MUX0);
		sbi(ADMUX, MUX1);	//A k�vetkez� l�b az ADC2
		ADC_state = NTC;
        break;

    case NTC:	//ADC2 l�bon az NTC-oszt� van
		cbi(ADMUX, MUX1);
		sbi(ADMUX, MUX0);	//A k�vetkez� l�b az ADC1
		ADC_state = poti;
        break;

    default:
        break;
    }
}