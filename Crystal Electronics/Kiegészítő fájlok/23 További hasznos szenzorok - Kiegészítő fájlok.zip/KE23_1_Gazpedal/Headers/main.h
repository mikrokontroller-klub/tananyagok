#ifndef MAIN_H_
#define MAIN_H_

#define F_CPU 8000000UL
#include <math.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include "../Headers/io.h"
#include "../Headers/timer.h"
#include "../Headers/adc.h"

//Konstansok
#define CNTR_MAX 1
//Csak a fels� 8 bitet haszn�lom, 5V a referencia
#define ADC_CONST 5.0/256.0

//F�ggv�nyek

#endif /* MAIN_H_ */