#include "../Headers/io.h"

void IOInit()
{
	//PORTA felh�z�ellen�ll�s kikapcsol�sa a bemeneteken
	PORTA=0x00;
	DDRA=0x00;
	sbi(DDRA,0);	//A LED a PA0-n van, PORTA0 legyen kimenet (0x01)
	
	//PORTB felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
	PORTB=0x00;
	DDRB=0x00;
	
	//PORTC felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
	PORTC=0x00;
	DDRC=0x00;
	
	//PORTD felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
	PORTD=0x00;
	DDRD=0x00;
}