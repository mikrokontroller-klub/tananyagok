#ifndef ADC_H_
#define ADC_H_

#include <avr/io.h>
#include <compat/deprecated.h>

//Konstansok

//V�ltoz�k
enum ADC_state_t
{
    poti1, poti2
};

extern volatile enum ADC_state_t ADC_state;

//F�ggv�nyek
void ADCInit();
void ADCEnable();
void ADCStart();
void NextCH();

#endif /* ADC_H_ */