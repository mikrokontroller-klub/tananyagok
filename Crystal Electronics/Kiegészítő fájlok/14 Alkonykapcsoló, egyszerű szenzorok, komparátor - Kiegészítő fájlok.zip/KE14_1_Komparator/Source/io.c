#include "../Headers/io.h"

void IOInit()
{
    //PORTA felh�z�ellen�ll�s kikapcsol�sa a bemeneteken
    PORTA = 0x00;
    DDRA = 0x00;

    //PORTB felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
    PORTB = 0x00;
    DDRB = 0x00;

    //PORTC felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
    PORTC = 0x00;
    DDRC = 0x00;

    //PORTD felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
    PORTD = 0x00;
    DDRD = 0x00;
    //LED kimenet
    sbi(DDRD, 6);
}

void ComparatorInit()
{
	//AIN0 �s AIN1 be�ll�t�sa bemenetk�nt
	AIN0_DDR &= ~(0<<AIN0_BIT);
	AIN1_DDR &= ~(0<<AIN1_BIT);
	//Kompar�tor regiszter be�ll�t�sai: 
		//ACD: Analog Comparator Disable
		//ACBG: Analog Comparator Bandgap Reference
		//ACIE: Analog Comparator Interrupt Enable
		//ACIC: Analog Comparator Interrupt Capture
	// Kompar�tor bekapcsolva, AIN0 referencia, megszak�t�s kikapcsolva, megszak�t�s eldob�sa (l�sd k�s�bb)
	ACSR = (0<<ACD) + (0<<ACBG) + (0<<ACIE) + (0<<ACIC);
}