#include "../Headers/adc.h"


void ADCInit()
{
	//AVCC referencia
	cbi(ADMUX, REFS1);	
	sbi(ADMUX, REFS0);
	
	//ADC1 bemenet
	sbi(ADMUX, MUX0);
	
	//Balra tolt eredm�ny -> fels� 8 bit ADCRH-ban
	sbi(ADMUX, ADLAR); 
}

void ADCEnable()
{
	//128-as presc
	sbi(ADCSRA, ADPS2);
	sbi(ADCSRA, ADPS1);
	sbi(ADCSRA, ADPS0);
	
	//Interrupt bekapcsol�sa
	sbi(ADCSRA,ADIE);
	
	//AD konverter bekapcsol�sa
	sbi(ADCSRA, ADEN);
}


void ADCStart()
{
	sbi(ADCSRA, ADSC);
}