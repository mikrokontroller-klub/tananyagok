/*
 * 14. Fejezet
 *
 * A PB2 (AIN0) pinre jut� fesz�lts�get egy potenciom�terrel �ll�tjuk be, m�g PB3 (AIN1) pinre egy h�m�r�t k�t�nk.
 * A mikrovez�rl�ben l�v� kompar�tor �sszehasonl�tja a k�t �rt�ket, a kimenet a PD6 pinre k�t�tt LED.
 */

#include "../Headers/main.h"

int main(void)
{
    //PORT-ok inicializ�l�sa
    IOInit();
	
	//Kompar�tor inicializ�l�sa
	ComparatorInit();

    //V�gtelen ciklus
    while (1)
    {
        //Kompar�tor kimenet�nek ellen�rz�se
        if (tbi(ACSR, ACO) != 0)
        {
            //Bekapcsoljuk a LED-et, ha a kimenet logikai magas
			sbi(PORTD, 6);
		}
		else
		{
			//Kikapcsoljuk a LED-et, ha a kimenet logikai alacsony
			cbi(PORTD, 6);
		}
    }
    return 0;
}