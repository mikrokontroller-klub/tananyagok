#ifndef IO_H_
#define IO_H_

#include <avr/io.h>
#include <compat/deprecated.h>

//Konstansok

//F�ggv�nyek
void IOInit();

void ComparatorInit();

#endif /* IO_H_ */