#ifndef PWM_H_
#define PWM_H_

#include <avr/io.h>
#include <compat/deprecated.h>

//Konstansok

//V�ltoz�k

//F�ggv�nyek
void PWMInit();

#endif /* PWM_H_ */