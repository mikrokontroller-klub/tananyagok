#ifndef IO_H_
#define IO_H_

#include <avr/io.h>
#include <compat/deprecated.h>
#include <avr/interrupt.h>

//Konstansok

//F�ggv�nyek
void IOInit();

#endif /* IO_H_ */