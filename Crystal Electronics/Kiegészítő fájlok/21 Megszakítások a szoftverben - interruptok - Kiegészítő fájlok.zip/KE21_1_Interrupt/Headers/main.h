#ifndef MAIN_H_
#define MAIN_H_

#define F_CPU 8000000UL
#include <util/delay.h>
#include <avr/interrupt.h>

#include "../Headers/io.h"

//Konstansok

//F�ggv�nyek

#endif /* MAIN_H_ */