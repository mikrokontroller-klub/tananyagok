#include "../Headers/io.h"

void IOInit()
{
    //PORTA felh�z�ellen�ll�s kikapcsol�sa a bemeneteken
    PORTA = 0x00;
    DDRA = 0x00;
    //1. LED a PA0-n van, PORTA0 legyen kimenet (0x01)
    sbi(DDRA, 0);
    //2. LED a PA1-n van, PORTA1 legyen kimenet (0x01)
    sbi(DDRA, 1);
    //3. LED a PA2-n van, PORTA2 legyen kimenet (0x01)
    sbi(DDRA, 2);

    //PORTB felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
    PORTB = 0x00;
    DDRB = 0x00;

    //PORTC felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
    PORTC = 0x00;
    DDRC = 0x00;

    //PORTD felh�z�ellen�ll�s kikapcsol�sa �s minden pin bemenet
    PORTD = 0x00;
    DDRD = 0x00;
	
	//INTR0 felfut� �lre, vagyis ISC00=ISC01=1	66.oldal
	sbi(MCUCR, ISC00);
	sbi(MCUCR, ISC01);
	//INTR1 felfut� �lre, vagyis ISC10=ISC11=1	67.oldal
	sbi(MCUCR, ISC10);
	sbi(MCUCR, ISC11);
	//External interrupt enged�lyez�s 68.oldal
	sbi(GICR, INTF0);
	sbi(GICR, INTF1);
	//Global interrupt enged�lyez�s	9.oldal
	sbi(SREG, 7);
}