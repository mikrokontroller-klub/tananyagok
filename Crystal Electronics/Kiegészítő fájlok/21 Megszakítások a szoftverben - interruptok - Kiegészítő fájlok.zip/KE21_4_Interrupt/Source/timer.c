#include "../Headers/timer.h"

void TimerInit()
{
	//8x el�oszt�s , 108. oldal
	cbi(TCCR1B, CS10);
	sbi(TCCR1B, CS11);
	cbi(TCCR1B, CS12);
}