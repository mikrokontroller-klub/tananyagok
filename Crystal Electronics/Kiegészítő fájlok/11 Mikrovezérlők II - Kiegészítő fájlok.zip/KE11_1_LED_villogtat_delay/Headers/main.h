#ifndef MAIN_H
#define MAIN_H

/*
 * A cpu frekvenci�t az #include <util/delay.h> direkt�va el�tt kell megadni,
 * ugyanis ebben a header f�jlban m�r sz�ks�g van r�.
 */
//8MHz-es �rajelle dolgozunk
#define F_CPU 8000000UL
#include <util/delay.h>
#include <avr/io.h>

#include "../Headers/io.h"

//Konstansok

//F�ggv�nyek

#endif