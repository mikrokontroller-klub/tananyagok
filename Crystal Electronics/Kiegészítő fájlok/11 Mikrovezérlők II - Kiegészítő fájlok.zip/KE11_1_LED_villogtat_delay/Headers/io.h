#ifndef IO_H_
#define IO_H_

#include <avr/io.h>
#include <compat/deprecated.h>

//Konstansok
#define BLINK_DELAY 500

//F�ggv�nyek
/*
 * Ki- �s bemenetek inicializ�l�sa
 */
void IOInit();

#endif /* IO_H_ */