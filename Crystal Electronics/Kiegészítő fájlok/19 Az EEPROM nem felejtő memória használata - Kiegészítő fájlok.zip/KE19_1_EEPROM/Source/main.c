/*
 * 19. Fejezet
 *
 * A PD4,5,6 pineken lev� kapcsol�kkal v�ltoztathat� meg a PD7,PC0, PC1 l�bak �llapota.
 * Az �llapot elment�sre ker�l az EEPROMba, �gy �jraind�t�s ut�n sem veszik el az inform�ci�.
 */

#include "../Headers/main.h"

//Az egyes LEDekhez tartoz� EEPROM mem�riab�jtok c�mei
const uint8_t* led1_ptr = 0x00;
const uint8_t* led2_ptr = 0x01;
const uint8_t* led3_ptr = 0x02;

int main(void)
{
    //PORT-ok inicializ�l�sa
    IOInit();

    //led1_ptr c�men lev� eeprom adat vizsg�lata
    if (eeprom_read_byte(led1_ptr) > 0)
    {
        sbi(PORTC, 1);
    }

    //led2_ptr c�men lev� eeprom adat vizsg�lata
    if (eeprom_read_byte(led2_ptr) > 0)
    {
        sbi(PORTC, 0);
    }

    //led3_ptr c�men lev� eeprom adat vizsg�lata
    if (eeprom_read_byte(led3_ptr) > 0)
    {
        sbi(PORTD, 7);
    }

    //V�gtelen ciklus
    while (1)
    {
        //Els� kapcsol� kezel�se, ha le van nyomva
        if (tbi(PIND, 4) != 0)
        {
            //Tranziensek lezajlanak ennyi id� alatt, perg�smentes�t�s
            _delay_ms(BTN_DELAY);

            //V�rakoz�s a felenged�sre
            while (tbi(PIND, 4) != 0);

            //Tranziensek lezajlanak ennyi id� alatt, perg�smentes�t�s
            _delay_ms(BTN_DELAY);

            //Ha a PC1 l�bon lev� LED vil�g�t
            if (tbi(PINC, 1))
            {
                //Az �j �llapot a "nem vil�g�t", ezt elmentem az EEPROMba
                eeprom_write_byte(led1_ptr, 0x00);
                //Kikapcsolom a LED-et
                cbi(PORTC, 1);
            }

            //Ha a PC1 l�bon lev� LED nem vil�g�t
            else
            {
                //Az �j �llapot a "vil�g�t", ezt elmentem az EEPROMba
                eeprom_write_byte(led1_ptr, 0xFF);
                //Bekapcsolom a LED-et
                sbi(PORTC, 1);
            }
        }

        if (tbi(PIND, 5) != 0)
        {
            _delay_ms(BTN_DELAY);

            while (tbi(PIND, 5) != 0);

            _delay_ms(BTN_DELAY);

            if (tbi(PINC, 0))
            {
                eeprom_write_byte(led2_ptr, 0x00);
                cbi(PORTC, 0);
            }

            else
            {
                eeprom_write_byte(led2_ptr, 0xFF);
                sbi(PORTC, 0);
            }
        }

        if (tbi(PIND, 6) != 0)
        {
            _delay_ms(BTN_DELAY);

            while (tbi(PIND, 6) != 0);

            _delay_ms(BTN_DELAY);

            if (tbi(PIND, 7))
            {
                eeprom_write_byte(led3_ptr, 0x00);
                cbi(PORTD, 7);
            }

            else
            {
                eeprom_write_byte(led3_ptr, 0xFF);
                sbi(PORTD, 7);
            }
        }
    }

    return 0;
}