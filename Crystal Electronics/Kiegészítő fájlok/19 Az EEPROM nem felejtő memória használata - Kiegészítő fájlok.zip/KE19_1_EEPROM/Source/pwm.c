#include "../Headers/pwm.h"

void PWMInit()
{
	/*�rajel
	A PWM frekvencia (adatlap 120.oldal) fpwm=fclkIO/(N*510), ahol N az �rajel oszt�sa.
	Ebb�l N=fclkIO/fpwm*1/510, vagyis 10kHz k�r�li frekvenci�hoz N=8e6/10e3*1/510=1.569 oszt�s kell.
	A mikrokontrollerben csak 1,8,32,64,128,256,1024 oszt�sok vannak, N=1-et v�lasztva
	fpwm=15.686kHz ad�dik.*/
	
	 //TIMER2 (PWM)
	 //1x el�oszt�s (126.oldal)
	 cbi(TCCR2, CS22);
	 cbi(TCCR2, CS21);
	 sbi(TCCR2, CS20);
	 
	 //Phase correct PWM m�d (125.oldal)
	 cbi(TCCR2, WGM21);
	 sbi(TCCR2, WGM20);
	 
	 //Pon�lt m�k�d�s (126.oldal)
	 sbi(TCCR2, COM21);
	 cbi(TCCR2, COM20);
}
