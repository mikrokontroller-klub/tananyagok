#include "../Headers/timer.h"
#include <avr/interrupt.h>

volatile uint8_t tmp;

void TimerInit()
{	 
	 //1x el�oszt�s
	 cbi(TCCR1B, CS12);
	 cbi(TCCR1B, CS11);
	 sbi(TCCR1B, CS10);
	 
	 //Timer1 interrupt be
	 sbi(TIMSK, TOIE1);	 
	 
	 //Glob�lis interrupt be
	 sei();
}
