#ifndef MAIN_H_
#define MAIN_H_

#define F_CPU 8000000UL
#include <util/delay.h>
#include <avr/eeprom.h>

#include "../Headers/io.h"

//Konstansok
#define BTN_DELAY 20

//F�ggv�nyek
/*
 * Bit tesztel� f�ggv�ny, az egyszer�bb kapcsol� �llapot vizsg�lathoz
 */
#define tbi(pin, bit) ((pin >> bit) & 1)

#endif /* MAIN_H_ */