#ifndef ADC_H_
#define ADC_H_

#include <avr/io.h>
#include <compat/deprecated.h>

//Konstansok

//V�ltoz�k

//F�ggv�nyek
void ADCInit();
void ADCEnable();
void ADCStart();

#endif /* ADC_H_ */