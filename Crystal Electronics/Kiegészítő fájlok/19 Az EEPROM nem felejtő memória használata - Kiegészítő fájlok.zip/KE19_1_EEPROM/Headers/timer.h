#ifndef TIMER_H_
#define TIMER_H_

//Include
#include <avr/io.h>
#include <compat/deprecated.h>

//Konstansok

//V�ltoz�k

//F�ggv�nyek
void TimerInit();

#endif /* TIMER_H_ */