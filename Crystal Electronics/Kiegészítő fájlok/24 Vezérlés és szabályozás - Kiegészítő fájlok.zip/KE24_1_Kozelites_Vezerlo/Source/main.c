/*
 * 24. Fejezet
 *
 * A PA1 l�bon (ADC1) lev� reflexi�s optoszenzor kimeneti fesz�lts�g�nek (AD �rt�k�nek)
 * als� 8 bitje beker�l a TMR2 PWM regiszter�be,
 * vagyis a szenzor �s az el�tte lev� t�rgy t�vols�g�nak f�ggv�ny�ben v�ltozik
 * a PD7 l�bon megjelen� PWM jel kit�lt�si t�nyez�je.
 */

#include "../Headers/main.h"

volatile uint32_t cntr = 0;

ISR(TIMER1_OVF_vect)
{
    //N�velem a leoszt� sz�ml�l�t, ha m�g nem �rte el a maximumot
    if (cntr < CNTR_MAX)
    {
        cntr++;
    }

    //Ha el�rte
    else
    {
        cntr = 0;
        //AD konverzi� indul (mintav�tel)
        ADCStart();
    }
}

//AD konverzi� k�sz, AD megszak�t�s
ISR(ADC_vect)
{
    uint16_t ad_res;
    //A szorz�ssal �s a 255-�s korl�ttal az �rz�kenys�g n�velhet�
    ad_res = ADCH * 4;

    if (ad_res > 255)
    {
        ad_res = 255;
    }

    //Az AD eredm�ny fels� 8 bitj�t belet�lti a PWM timer regiszter�be
    OCR2 = ad_res;
}

int main(void)
{
    IOInit();
    TimerInit();
    PWMInit();
    ADCInit();

    //AD bekapcsol�sa
    ADCEnable();

    //PWM kit�lt�se legyen kezdetben 0
    OCR2 = 0;

    //V�gtelen ciklus
    while (1)
    {

    }

    return 0;
}