/*
 * 22. Fejezet
 *
 * A PA1 (ADC1) l�bon lev� potenciom�ter fesz�lts�g�t �sszehasonl�tja
 * az NTC-vel l�trehozott fesz�lts�goszt� fesz�lts�g�vel (AD konverzi�).
 * Ha az NTC fesz�lts�ge nagyobb mint a potenciom�teren m�rhet�,
 * akkor a PA0 l�bon lev� LED kigyullad. Ellenkez� esetben nem vil�g�t.
 */

#include "../Headers/main.h"

volatile uint32_t cntr = 0;
volatile double U_poti = 0;
volatile double U_NTC = 0;

//Timer1 megszak�t�s
ISR(TIMER1_OVF_vect)
{
    //N�velem a leoszt� sz�ml�l�t, ha m�g nem �rte el a maximumot
    if (cntr < CNTR_MAX)
    {
        cntr++;
    }

    //Ha el�rte
    else
    {
        cntr = 0;
        //AD konverzi� indul (mintav�tel)
        ADCStart();
    }
}

//AD konverzi� k�sz, AD megszak�t�s
ISR(ADC_vect)
{
    //Az AD csatorna alapj�n a megfelel� v�ltoz�ba menti a m�rt fesz�lts�get
    switch (ADC_state)
    {
    case poti:
        U_poti = ADCH * ADC_CONST;
        break;

    case NTC:
        U_NTC = ADCH * ADC_CONST;
        break;

    default:
        break;
    }

    //V�lt�s a k�vetkez� AD csatorn�ra
    NextCH();
}

int main(void)
{
    IOInit();
    TimerInit();
    ADCInit();

    //AD bekapcsol�s
    ADCEnable();

    //V�gtelen ciklus
    while (1)
    {
        //Ha az NTC oszt� fesz�lts�ge nagyobb a poti�n�l, akkor vil�g�tson a LED
        if (U_NTC > U_poti)
        {
            sbi(PORTA, 0);
        }

        //Egy�bk�nt ne vil�g�tson
        else
        {
            cbi(PORTA, 0);
        }
    }

    return 0;
}