#ifndef MAIN_H_
#define MAIN_H_

#define F_CPU 8000000UL
#include <util/delay.h>

#include "../Headers/adc.h"
#include "../Headers/io.h"
#include "../Headers/pwm.h"
#include "../Headers/timer.h"

//Konstansok
#define CNTR_MAX 10

//F�ggv�nyek

#endif /* MAIN_H_ */