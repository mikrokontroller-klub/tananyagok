#ifndef TIMER_H_
#define TIMER_H_

#include <avr/io.h>
#include <compat/deprecated.h>
#include <avr/interrupt.h>

//Konstansok

//F�ggv�nyek
void TimerInit();

#endif /* TIMER_H_ */