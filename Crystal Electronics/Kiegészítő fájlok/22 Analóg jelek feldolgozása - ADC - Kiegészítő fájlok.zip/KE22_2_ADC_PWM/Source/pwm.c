#include "../Headers/pwm.h"

void PWMInit()
{
    //TIMER2 (PWM)
    //1x el�oszt�s (126.oldal)
    cbi(TCCR2, CS22);
    cbi(TCCR2, CS21);
    sbi(TCCR2, CS20);

    //Phase correct PWM m�d (125.oldal)
    cbi(TCCR2, WGM21);
    sbi(TCCR2, WGM20);

    //Pon�lt m�k�d�s (126.oldal)
    sbi(TCCR2, COM21);
    cbi(TCCR2, COM20);
}
