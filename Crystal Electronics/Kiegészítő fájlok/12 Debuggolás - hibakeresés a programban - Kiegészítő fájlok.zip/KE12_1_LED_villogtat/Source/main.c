/*
 * 12. Fejezet
 *
 * A mikrovez�rl� PA0 l�b�ra k�t�tt LED-et villogtatja delay f�ggv�ny seg�ts�g�vel.
 *
 */

#include "../Headers/main.h"

int main(void)
{
    //PORTok inicializ�l�sa
    IOInit();

    //V�gtelen ciklusban villogtatja a LED-et
    while (1)
    {
        //Bekapcsolja a LED-et
        PORTA = 0b0000001;
		//Kikapcsolja a LED-et
        PORTA = 0b0000000;
    }

    //A v�gtelen ciklus miatt ez a k�d m�r nem fut le, a ford�t� azonban hi�nyoln� a return-t
    return 0;
}